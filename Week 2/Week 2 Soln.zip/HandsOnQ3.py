# Hands-on 1 Q3 - Check if a number is even or odd

num = int(input("Enter an integer: "))
if num%2 == 0:
    print("Even")
else:
    print("Odd")
