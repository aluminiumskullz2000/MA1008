# Hands-on 1 Q 4: Compute BMI

weight = float(input("Body weight in kg: "))
height = float(input("Height in meters: "))

BMI = weight/(height*height)

print("Your body-mass index is ", BMI)
